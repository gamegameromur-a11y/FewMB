#include "browser.h"

namespace FewMB {

struct Bookmark {
    int id;
    std::wstring url;
    std::wstring title;
    std::wstring folder;
    int64_t createdAt;
    int visitCount;
};

struct HistoryItem {
    int id;
    std::wstring url;
    std::wstring title;
    int64_t visitedAt;
    int visitCount;
};

struct DownloadItem {
    std::string id;
    std::wstring url;
    std::wstring filename;
    std::wstring savePath;
    int64_t totalBytes;
    int64_t downloadedBytes;
    double progress;
    int status;
    int64_t startTime;
};

ColorId Color::getId() const {
    uint64_t h = ((uint64_t)r << 24) | ((uint64_t)g << 16) | ((uint64_t)b << 8) | a;
    h ^= h >> 16; h *= 0x85EBCA6B; h ^= h >> 13; h *= 0xC2B2AE35; h ^= h >> 16;
    return (ColorId)(h & 0xFFFFFFFF);
}

Browser& Browser::get() {
    static Browser instance;
    return instance;
}

Browser::Browser()
    : nextTabId(1), activeTabId(0), running(false)
    , assistantVisible(false), settingsVisible(false), downloadsVisible(false)
    , bookmarksVisible(false), historyVisible(false), currentTheme(2), splitMode(0)
{
}

Browser::~Browser() { shutdown(); }

void Browser::init() {
    log("FewMB initializing...");

    WNDCLASSEXW wc = { sizeof(WNDCLASSEXW) };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.lpszClassName = CLASS_NAME;
    wc.hIcon = (HICON)LoadImage(nullptr, IDI_APPLICATION, IMAGE_ICON, 0, 0, LR_SHARED);
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(RGB(30, 30, 30));
    RegisterClassExW(&wc);

    wc.lpszClassName = TAB_CLASS;
    wc.hbrBackground = CreateSolidBrush(RGB(25, 25, 25));
    RegisterClassExW(&wc);

    wc.lpszClassName = ASSISTANT_CLASS;
    wc.style = WS_POPUP | WS_CAPTION | WS_SYSMENU;
    wc.hbrBackground = CreateSolidBrush(RGB(35, 35, 35));
    RegisterClassExW(&wc);

    wc.lpszClassName = SETTINGS_CLASS;
    RegisterClassExW(&wc);

    wc.lpszClassName = DOWNLOADS_CLASS;
    RegisterClassExW(&wc);

    wc.lpszClassName = MENU_CLASS;
    wc.style = WS_POPUP;
    wc.hbrBackground = CreateSolidBrush(RGB(45, 45, 45));
    RegisterClassExW(&wc);

    loadConfig();
    createWindow();
    checkForUpdates();

    log("FewMB initialized");
}

void Browser::createWindow() {
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);
    int w = sw * 85 / 100;
    int h = sh * 85 / 100;

    hwnd = CreateWindowExW(0, CLASS_NAME, L"FewMB Browser",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        (sw - w) / 2, (sh - h) / 2, w, h, nullptr, nullptr,
        GetModuleHandle(nullptr), this);

    if (!hwnd) {
        log("Failed to create window", 4);
        return;
    }

    createControls();
    ShowWindow(hwnd, SW_SHOW);
    updateTheme();

    createTab(L"https://www.google.com");
}

void Browser::createControls() {
    DWORD bs = WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_TABSTOP;
    DWORD es = WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP;

    backBtn = CreateWindowExW(0, L"BUTTON", L"\x2190", bs, 8, 8, 32, 32, hwnd, (HMENU)1, GetModuleHandle(nullptr), nullptr);
    forwardBtn = CreateWindowExW(0, L"BUTTON", L"\x2192", bs, 44, 8, 32, 32, hwnd, (HMENU)2, GetModuleHandle(nullptr), nullptr);
    refreshBtn = CreateWindowExW(0, L"BUTTON", L"\x21BB", bs, 80, 8, 32, 32, hwnd, (HMENU)3, GetModuleHandle(nullptr), nullptr);
    homeBtn = CreateWindowExW(0, L"BUTTON", L"\x2302", bs, 116, 8, 32, 32, hwnd, (HMENU)4, GetModuleHandle(nullptr), nullptr);

    addressBar = CreateWindowExW(0, L"EDIT", L"", es, 156, 10, 600, 28, hwnd, (HMENU)100, GetModuleHandle(nullptr), nullptr);
    SendMessage(addressBar, EM_SETREADONLY, TRUE, 0);

    int rx = 780;
    settingsBtn = CreateWindowExW(0, L"BUTTON", L"\x2699", bs, rx, 8, 32, 32, hwnd, (HMENU)10, GetModuleHandle(nullptr), nullptr); rx -= 36;
    bookmarksBtn = CreateWindowExW(0, L"BUTTON", L"\x2605", bs, rx, 8, 32, 32, hwnd, (HMENU)11, GetModuleHandle(nullptr), nullptr); rx -= 36;
    downloadsBtn = CreateWindowExW(0, L"BUTTON", L"\x2193", bs, rx, 8, 32, 32, hwnd, (HMENU)12, GetModuleHandle(nullptr), nullptr); rx -= 36;
    assistantBtn = CreateWindowExW(0, L"BUTTON", L"\x2728", bs, rx, 8, 32, 32, hwnd, (HMENU)13, GetModuleHandle(nullptr), nullptr); rx -= 36;
    menuBtn = CreateWindowExW(0, L"BUTTON", L"\x2630", bs, rx, 8, 32, 32, hwnd, (HMENU)14, GetModuleHandle(nullptr), nullptr);

    contentWnd = CreateWindowExW(0, L"STATIC", L"", WS_CHILD | WS_VISIBLE, 0, 48, 100, 100, hwnd, (HMENU)200, GetModuleHandle(nullptr), nullptr);
    statusWnd = CreateWindowExW(0, L"STATIC", L"Ready", WS_CHILD | WS_VISIBLE, 0, 0, 100, 24, hwnd, (HMENU)201, GetModuleHandle(nullptr), nullptr);

    SetWindowSubclass(addressBar, [](HWND h, UINT m, WPARAM w, LPARAM l, UINT_PTR, DWORD_PTR) -> LRESULT {
        if (m == WM_KEYDOWN && w == VK_RETURN) {
            wchar_t buf[4096];
            GetWindowTextW(h, buf, 4096);
            Browser::get().navigate(buf);
        }
        return DefSubclassProc(h, m, w, l);
    }, 0, 0);
}

void Browser::updateLayout() {
    RECT r;
    GetClientRect(hwnd, &r);
    int cy = r.bottom - 72;
    MoveWindow(contentWnd, 0, 48, r.right, cy);
    MoveWindow(statusWnd, 0, r.bottom - 24, r.right, 24);

    RECT cr;
    GetClientRect(contentWnd, &cr);
    Tab* tab = getActiveTab();
    if (tab && tab->webView) {
        RECT bounds = { 0, 0, cr.right, cr.bottom };
        tab->webView->put_Bounds(bounds);
    }
}

LRESULT CALLBACK Browser::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    Browser* app = (Browser*)GetWindowLongPtrW(hwnd, GWLP_USERDATA);

    if (!app && msg == WM_NCCREATE) {
        CREATESTRUCTW* cs = (CREATESTRUCTW*)lParam;
        app = (Browser*)cs->lpCreateParams;
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, (LONG_PTR)app);
    }

    if (!app) return DefWindowProcW(hwnd, msg, wParam, lParam);

    switch (msg) {
    case WM_SIZE:
        app->updateLayout();
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case 1: app->navigateBack(); break;
        case 2: app->navigateForward(); break;
        case 3: app->refresh(); break;
        case 4: app->navigate(L"https://www.google.com"); break;
        case 10: app->isSettingsVisible() ? app->hideSettings() : app->showSettings(); break;
        case 11: app->isBookmarksVisible() ? app->hideBookmarks() : app->showBookmarks(); break;
        case 12: app->isDownloadsVisible() ? app->hideDownloads() : app->showDownloads(); break;
        case 13: app->isAssistantVisible() ? app->hideAssistant() : app->showAssistant(); break;
        case 14: app->showMenu(); break;
        case 1000: app->createTab(); break;
        }
        return 0;

    case WM_DESTROY:
        app->shutdown();
        PostQuitMessage(0);
        return 0;

    case WM_KEYDOWN:
        if (GetKeyState(VK_CONTROL) & 0x8000) {
            switch (wParam) {
            case 'T': app->createTab(); break;
            case 'W': { Tab* t = app->getActiveTab(); if (t) app->closeTab(t->id); } break;
            case 'L': SetFocus(app->addressBar); break;
            case 'H': app->showHistory(); break;
            case 'B': app->addBookmark(app->getActiveTab()->url, app->getActiveTab()->title); break;
            case 'D': app->showDownloads(); break;
            case 'P': app->showSettings(); break;
            }
        }
        if (GetKeyState(VK_F5) & 0x8000) app->refresh();
        if (GetKeyState(VK_F11) & 0x8000) app->setSplitMode(app->getSplitMode() ? 0 : 1);
        return 0;

    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLOREDIT: {
        HDC dc = (HDC)wParam;
        SetBkColor(dc, RGB(45, 45, 45));
        SetTextColor(dc, RGB(220, 220, 220));
        return (LRESULT)CreateSolidBrush(RGB(45, 45, 45));
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        BeginPaint(hwnd, &ps);
        EndPaint(hwnd, &ps);
        return 0;
    }
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

Tab* Browser::createTab(const std::wstring& url) {
    std::lock_guard<std::mutex> lock(tabsMutex);
    int id = nextTabId++;
    auto tab = std::make_shared<Tab>(id);
    tab->url = url.empty() ? L"about:blank" : url;

    createWebViewForTab(tab.get(), contentWnd, tab->url);

    tabs.push_back(tab);
    if (activeTabId == 0) activeTabId = id;

    updateTabBar();
    log("Tab created: " + std::to_string(id));
    return tab.get();
}

bool Browser::createWebViewForTab(Tab* tab, HWND parent, const std::wstring& url) {
    RECT bounds;
    GetClientRect(parent, &bounds);

    auto env = CreateWebView2EnvironmentAsync(nullptr);
    if (!env) return false;

    env->then([this, tab, bounds, url](IWebView2Environment* environment, HRESULT hr) {
        if (FAILED(hr) || !environment) return;

        environment->CreateWebView(tab->id == activeTabId ? contentWnd : GetDesktopWindow(), [this, tab, bounds, url](IWebView2WebView* webview, HRESULT hr2) {
            if (FAILED(hr2) || !webview) return;

            tab->webView = webview;
            webview->put_Bounds(bounds);

            IWebView2Settings* settings;
            webview->get_Settings(&settings);
            settings->put_IsZoomControlEnabled(TRUE);
            settings->put_AreDevToolsEnabled(TRUE);
            settings->put_IsStatusBarEnabled(FALSE);

            EventRegistrationToken navStart, navComplete, titleChanged, sourceChanged;

            webview->add_NavigationStarting([this, tab](IWebView2WebView*, IWebView2NavigationStartingEventArgs* args) {
                tab->isLoading = true;
                wchar_t* uri;
                args->get_Uri(&uri);
                if (uri) {
                    tab->url = uri;
                    if (tab->id == activeTabId) SetWindowTextW(addressBar, uri);
                }
            });

            webview->add_NavigationCompleted([this, tab](IWebView2WebView*, IWebView2NavigationCompletedEventArgs* args) {
                tab->isLoading = false;
                BOOL ok;
                args->get_IsSuccess(&ok);
                if (tab->id == activeTabId) {
                    wchar_t* title;
                    tab->webView->get_Title(&title);
                    if (title) {
                        tab->title = title;
                        SetWindowTextW(hwnd, (L"FewMB - " + tab->title).c_str());
                    }
                    updateTabBar();
                    addToHistory(tab->url, tab->title);
                }
            });

            webview->add_TitleChanged([this, tab](IWebView2WebView*, IWebView2TitleChangedEventArgs* args) {
                wchar_t* title;
                args->get_Title(&title);
                if (title) {
                    tab->title = title;
                    if (tab->id == activeTabId) SetWindowTextW(hwnd, (L"FewMB - " + tab->title).c_str());
                    updateTabBar();
                }
            });

            if (!url.empty() && url != L"about:blank") {
                webview->Navigate(url.c_str());
            }
        });
    });

    return true;
}

void Browser::closeTab(int id) {
    std::lock_guard<std::mutex> lock(tabsMutex);
    auto it = std::find_if(tabs.begin(), tabs.end(), [id](auto& t) { return t->id == id; });
    if (it != tabs.end()) {
        if ((*it)->webView) {
            (*it)->webView->Close();
        }
        tabs.erase(it);
        log("Tab closed: " + std::to_string(id));

        if (tabs.empty()) {
            createTab();
        } else if (activeTabId == id) {
            activeTabId = tabs.front()->id;
            SetWindowTextW(addressBar, tabs.front()->url.c_str());
            updateLayout();
        }
        updateTabBar();
    }
}

Tab* Browser::getTab(int id) {
    std::lock_guard<std::mutex> lock(tabsMutex);
    for (auto& t : tabs) if (t->id == id) return t.get();
    return nullptr;
}

Tab* Browser::getActiveTab() {
    return getTab(activeTabId);
}

void Browser::setActiveTab(int id) {
    activeTabId = id;
    Tab* tab = getTab(id);
    if (tab) {
        SetWindowTextW(addressBar, tab->url.c_str());
        updateLayout();
        updateTabBar();
    }
}

void Browser::navigate(const std::wstring& input) {
    std::wstring url = input;
    if (input.find(L"://") == std::wstring::npos && input.find(L"about:") == std::wstring::npos) {
        if (input.find(L'.') != std::wstring::npos) {
            url = L"https://" + input;
        } else {
            url = L"https://www.google.com/search?q=" + input;
        }
    }
    Tab* tab = getActiveTab();
    if (tab) {
        tab->url = url;
        SetWindowTextW(addressBar, url.c_str());
        if (tab->webView) {
            tab->webView->Navigate(url.c_str());
        }
    }
}

void Browser::navigateBack() {
    Tab* tab = getActiveTab();
    if (tab && tab->webView) tab->webView->GoBack();
}

void Browser::navigateForward() {
    Tab* tab = getActiveTab();
    if (tab && tab->webView) tab->webView->GoForward();
}

void Browser::refresh() {
    Tab* tab = getActiveTab();
    if (tab && tab->webView) tab->webView->Reload();
}

void Browser::showAssistant() {
    if (!assistantWnd) {
        assistantWnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, ASSISTANT_CLASS, L"FewMB Assistant",
            WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
            100, 100, 500, 600, hwnd, nullptr, GetModuleHandle(nullptr), nullptr);
    }
    assistantVisible = true;
    SetWindowPos(assistantWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
}

void Browser::hideAssistant() {
    if (assistantWnd) ShowWindow(assistantWnd, SW_HIDE);
    assistantVisible = false;
}

void Browser::showSettings() {
    log("Settings opened");
    settingsVisible = true;
}

void Browser::hideSettings() {
    settingsVisible = false;
}

void Browser::showDownloads() {
    log("Downloads opened");
    downloadsVisible = true;
}

void Browser::hideDownloads() {
    downloadsVisible = false;
}

void Browser::showBookmarks() {
    log("Bookmarks opened");
    bookmarksVisible = true;
}

void Browser::hideBookmarks() {
    bookmarksVisible = false;
}

void Browser::showHistory() {
    log("History opened");
    historyVisible = true;
}

void Browser::hideHistory() {
    historyVisible = false;
}

void Browser::showMenu() {
    HMENU menu = CreatePopupMenu();
    AppendMenu(menu, MF_STRING, 1, L"New Tab\tCtrl+T");
    AppendMenu(menu, MF_STRING, 2, L"New Window");
    AppendMenu(menu, MF_SEPARATOR, 0, L"");
    AppendMenu(menu, MF_STRING, 3, L"Bookmarks");
    AppendMenu(menu, MF_STRING, 4, L"History\tCtrl+H");
    AppendMenu(menu, MF_STRING, 5, L"Downloads\tCtrl+D");
    AppendMenu(menu, MF_STRING, 6, L"Settings\tCtrl+P");
    AppendMenu(menu, MF_SEPARATOR, 0, L"");
    AppendMenu(menu, MF_STRING, 7, L"Exit");

    POINT pt;
    GetCursorPos(&pt);
    TrackPopupMenu(menu, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, nullptr);
    DestroyMenu(menu);
}

void Browser::updateTabBar() {
    InvalidateRect(tabBarWnd, nullptr, TRUE);
}

void Browser::updateStatusBar() {
    Tab* tab = getActiveTab();
    std::wstring status = tab ? (tab->isLoading ? L"Loading..." : L"Ready") : L"Ready";
    SetWindowTextW(statusWnd, status.c_str());
}

void Browser::updateTheme() {
    bool dark = currentTheme == 2 || (currentTheme == 0 && isDarkMode());

    SetClassLongPtr(hwnd, GCLP_HBRBACKGROUND, (LONG_PTR)CreateSolidBrush(dark ? RGB(30, 30, 30) : RGB(240, 240, 240)));
    SetClassLongPtr(tabBarWnd, GCLP_HBRBACKGROUND, (LONG_PTR)CreateSolidBrush(dark ? RGB(25, 25, 25) : RGB(230, 230, 230)));

    RedrawWindow(hwnd, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE);
}

bool Browser::isDarkMode() const {
    if (currentTheme == 1) return false;
    if (currentTheme == 2) return true;
    DWORD val = 0;
    SystemParametersInfoW(0x2000F, 0, &val, 0);
    return val != 0;
}

void Browser::setTheme(int t) {
    currentTheme = t;
    updateTheme();
}

void Browser::setSplitMode(int m) {
    splitMode = m;
    updateLayout();
}

void Browser::checkForUpdates() {
    std::thread([this]() {
        std::wstring apiUrl = L"https://api.github.com/repos/TOREofficial/FewMB/releases/latest";

        HINTERNET session = WinHttpOpen(L"FewMB/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, nullptr, nullptr, 0);
        if (!session) return;

        std::wstring host = L"api.github.com";
        std::wstring path = L"/repos/TOREofficial/FewMB/releases/latest";

        HINTERNET conn = WinHttpConnect(session, host.c_str(), 443, 0);
        if (!conn) { WinHttpCloseHandle(session); return; }

        HINTERNET req = WinHttpOpenRequest(conn, L"GET", path.c_str(), nullptr, nullptr, nullptr,
            WINHTTP_FLAG_SECURE);
        if (!req) { WinHttpCloseHandle(conn); WinHttpCloseHandle(session); return; }

        WinHttpSendRequest(req, nullptr, 0, nullptr, 0, 0, 0);
        WinHttpReceiveResponse(req, nullptr);

        std::string response;
        char buf[4096];
        DWORD bytes;
        while (WinHttpReadData(req, buf, sizeof(buf), &bytes) && bytes > 0) {
            response.append(buf, bytes);
        }

        WinHttpCloseHandle(req);
        WinHttpCloseHandle(conn);
        WinHttpCloseHandle(session);

        if (response.find("\"tag_name\"") != std::string::npos) {
            size_t tagPos = response.find("\"tag_name\"");
            size_t start = response.find("\"v", tagPos);
            size_t end = response.find("\"", start + 2);
            if (start != std::string::npos && end != std::string::npos) {
                latestVersion = a2w(response.substr(start + 1, end - start - 2));
                if (latestVersion != L"1.0.0") {
                    updateAvailable = true;
                    log("Update available: " + w2a(latestVersion));
                }
            }
        }
    }).detach();
}

void Browser::downloadAndInstallUpdate() {
    log("Downloading update...");
}

void Browser::executeJs(const std::wstring& script) {
    Tab* tab = getActiveTab();
    if (tab && tab->webView) {
        tab->webView->ExecuteScript(script.c_str(), nullptr);
    }
}

std::wstring Browser::getAppDataPath() {
    wchar_t path[MAX_PATH];
    SHGetFolderPathW(nullptr, CSIDL_APPDATA, nullptr, 0, path);
    std::wstring p = std::wstring(path) + L"\\FewMB";
    CreateDirectoryW(p.c_str(), nullptr);
    return p;
}

std::wstring Browser::getConfigPath() {
    return getAppDataPath() + L"\\config.ini";
}

void Browser::saveConfig() {
    std::wofstream f(getConfigPath());
    if (!f.is_open()) return;
    f << L"theme=" << currentTheme << L"\n";
    f << L"splitMode=" << splitMode << L"\n";
    f.close();
}

void Browser::loadConfig() {
    std::wifstream f(getConfigPath());
    if (!f.is_open()) return;
    std::wstring line;
    while (std::getline(f, line)) {
        size_t pos = line.find(L'=');
        if (pos != std::wstring::npos) {
            std::wstring key = line.substr(0, pos);
            std::wstring val = line.substr(pos + 1);
            if (key == L"theme") currentTheme = _wtoi(val.c_str());
            if (key == L"splitMode") splitMode = _wtoi(val.c_str());
        }
    }
    f.close();
}

void Browser::addBookmark(const std::wstring& url, const std::wstring& title) {
    Bookmark bm;
    bm.id = (int)bookmarks.size() + 1;
    bm.url = url;
    bm.title = title;
    bm.createdAt = GetTickCount64();
    bookmarks.push_back(bm);
    log("Bookmark added: " + w2a(url));
}

void Browser::removeBookmark(int id) {
    bookmarks.erase(std::remove_if(bookmarks.begin(), bookmarks.end(), [id](auto& b) { return b.id == id; }), bookmarks.end());
}

std::vector<Bookmark> Browser::getBookmarks() { return bookmarks; }
std::vector<Bookmark> Browser::searchBookmarks(const std::wstring& query) {
    std::vector<Bookmark> r;
    for (auto& b : bookmarks) {
        if (b.title.find(query) != std::wstring::npos || b.url.find(query) != std::wstring::npos)
            r.push_back(b);
    }
    return r;
}

void Browser::addToHistory(const std::wstring& url, const std::wstring& title) {
    HistoryItem hi;
    hi.id = (int)history.size() + 1;
    hi.url = url;
    hi.title = title;
    hi.visitedAt = GetTickCount64();
    history.push_back(hi);
}

std::vector<HistoryItem> Browser::getHistory(int limit) {
    std::vector<HistoryItem> h = history;
    if (limit > 0 && h.size() > limit) h.resize(limit);
    return h;
}

std::vector<HistoryItem> Browser::searchHistory(const std::wstring& query) {
    std::vector<HistoryItem> r;
    for (auto& h : history) {
        if (h.title.find(query) != std::wstring::npos || h.url.find(query) != std::wstring::npos)
            r.push_back(h);
    }
    return r;
}

void Browser::clearHistory(int64_t before) {
    if (before == 0) history.clear();
    else {
        history.erase(std::remove_if(history.begin(), history.end(),
            [before](auto& h) { return h.visitedAt < before; }), history.end());
    }
}

std::string Browser::startDownload(const std::wstring& url) {
    std::string id = "dl_" + std::to_string(rand() % 100000);
    DownloadItem dl;
    dl.id = id;
    dl.url = url;
    dl.status = 0;
    dl.startTime = GetTickCount64();
    downloads.push_back(dl);
    log("Download started: " + w2a(url));
    return id;
}

void Browser::pauseDownload(const std::string& id) {
    for (auto& d : downloads) {
        if (d.id == id) { d.status = 2; break; }
    }
}

void Browser::resumeDownload(const std::string& id) {
    for (auto& d : downloads) {
        if (d.id == id) { d.status = 1; break; }
    }
}

void Browser::cancelDownload(const std::string& id) {
    downloads.erase(std::remove_if(downloads.begin(), downloads.end(),
        [&id](auto& d) { return d.id == id; }), downloads.end());
}

std::vector<DownloadItem> Browser::getDownloads() { return downloads; }

LRESULT CALLBACK Browser::TabBarProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    Browser* app = (Browser*)GetWindowLongPtrW(hwnd, GWLP_USERDATA);
    if (!app) return DefWindowProcW(hwnd, msg, wParam, lParam);

    switch (msg) {
    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);
        int tabW = 150;
        int tabX = 4;
        for (auto& tab : app->tabs) {
            if (x >= tabX && x < tabX + tabW - 20) {
                app->setActiveTab(tab->id);
                return 0;
            }
            if (x >= tabX + tabW - 20 && x < tabX + tabW) {
                app->closeTab(tab->id);
                return 0;
            }
            tabX += tabW + 4;
        }
        if (x >= tabX && x < tabX + 30) {
            app->createTab();
        }
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        RECT r;
        GetClientRect(hwnd, &r);
        bool dark = app->isDarkMode();
        HBRUSH bg = CreateSolidBrush(dark ? RGB(25, 25, 25) : RGB(230, 230, 230));
        FillRect(dc, &r, bg);
        DeleteObject(bg);

        int tabW = 150;
        int tabX = 4;
        for (auto& tab : app->tabs) {
            bool active = tab->id == app->activeTabId;
            RECT tr = { tabX, 2, tabX + tabW, r.bottom - 2 };
            HBRUSH tabBg = CreateSolidBrush(active ? (dark ? RGB(35, 35, 35) : RGB(255, 255, 255)) : (dark ? RGB(30, 30, 30) : RGB(240, 240, 240)));
            FillRect(dc, &tr, tabBg);
            DeleteObject(tabBg);

            SetBkMode(dc, TRANSPARENT);
            SetTextColor(dc, active ? RGB(255, 255, 255) : RGB(180, 180, 180));
            std::wstring title = tab->title.empty() ? L"New Tab" : tab->title;
            if (title.length() > 18) title = title.substr(0, 15) + L"...";
            RECT textR = { tabX + 8, 8, tabX + tabW - 28, r.bottom - 8 };
            DrawTextW(dc, title.c_str(), -1, &textR, DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);

            RECT closeR = { tabX + tabW - 24, 8, tabX + tabW - 4, r.bottom - 8 };
            DrawTextW(dc, L"x", -1, &closeR, DT_CENTER | DT_VCENTER);

            if (active) {
                HPEN pen = CreatePen(PS_SOLID, 2, RGB(100, 150, 255));
                SelectObject(dc, pen);
                MoveToEx(dc, tabX, r.bottom - 2, nullptr);
                LineTo(dc, tabX + tabW, r.bottom - 2);
                DeleteObject(pen);
            }
            tabX += tabW + 4;
        }

        EndPaint(hwnd, &ps);
        return 0;
    }
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK Browser::AssistantProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    Browser* app = (Browser*)GetWindowLongPtrW(hwnd, GWLP_USERDATA);
    if (!app) return DefWindowProcW(hwnd, msg, wParam, lParam);

    static HWND chatArea = nullptr;
    static HWND inputArea = nullptr;

    switch (msg) {
    case WM_CREATE: {
        bool dark = app->isDarkMode();
        CreateWindowExW(0, L"STATIC", L"FewMB Assistant - AI Assistant",
            WS_CHILD | WS_VISIBLE | SS_CENTER, 0, 0, 500, 30, hwnd, nullptr, GetModuleHandle(nullptr), nullptr);

        chatArea = CreateWindowExW(0, L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_READONLY | WS_VSCROLL | ES_AUTOHSCROLL,
            0, 30, 500, 470, hwnd, (HMENU)1, GetModuleHandle(nullptr), nullptr);

        inputArea = CreateWindowExW(0, L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | ES_LEFT | ES_MULTILINE,
            5, 500, 420, 60, hwnd, (HMENU)2, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"Send",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            430, 500, 65, 60, hwnd, (HMENU)3, GetModuleHandle(nullptr), nullptr);
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(wParam) == 3) {
            wchar_t buf[8192];
            GetWindowTextW(inputArea, buf, 8192);
            if (wcslen(buf) > 0) {
                std::wstring input = buf;
                app->assistantHistory += L"You: " + input + L"\n\n";

                std::wstring response = app->processAssistantMessage(input);
                app->assistantHistory += L"FewMB: " + response + L"\n\n";

                SetWindowTextW(chatArea, app->assistantHistory.c_str());
                SetWindowTextW(inputArea, L"");
                SetFocus(inputArea);
            }
        }
        return 0;
    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wParam;
        SetBkColor(dc, RGB(35, 35, 35));
        SetTextColor(dc, RGB(220, 220, 220));
        return (LRESULT)CreateSolidBrush(RGB(35, 35, 35));
    }
    case WM_CLOSE:
        ShowWindow(hwnd, SW_HIDE);
        app->assistantVisible = false;
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK Browser::SettingsProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        CreateWindowExW(0, L"STATIC", L"Settings",
            WS_CHILD | WS_VISIBLE | SS_CENTERIMAGE, 10, 10, 200, 30, hwnd, nullptr, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"Dark Theme",
            WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
            10, 50, 200, 30, hwnd, (HMENU)101, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"Light Theme",
            WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
            10, 85, 200, 30, hwnd, (HMENU)102, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"System Theme",
            WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
            10, 120, 200, 30, hwnd, (HMENU)103, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"Clear History",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            10, 160, 150, 35, hwnd, (HMENU)201, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"Export Bookmarks",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            170, 160, 150, 35, hwnd, (HMENU)202, GetModuleHandle(nullptr), nullptr);

        CreateWindowExW(0, L"BUTTON", L"Check Updates",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            10, 200, 150, 35, hwnd, (HMENU)301, GetModuleHandle(nullptr), nullptr);
        return 0;
    }
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case 101: Browser::get().setTheme(2); break;
        case 102: Browser::get().setTheme(1); break;
        case 103: Browser::get().setTheme(0); break;
        case 201: Browser::get().clearHistory(); MessageBoxW(hwnd, L"History cleared", L"FewMB", MB_OK); break;
        case 202: /* export bookmarks */ break;
        case 301: Browser::get().checkForUpdates(); break;
        }
        return 0;
    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wParam;
        SetBkColor(dc, RGB(40, 40, 40));
        SetTextColor(dc, RGB(220, 220, 220));
        return (LRESULT)CreateSolidBrush(RGB(40, 40, 40));
    }
    case WM_CLOSE:
        ShowWindow(hwnd, SW_HIDE);
        Browser::get().settingsVisible = false;
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK Browser::DownloadsProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        CreateWindowExW(0, L"STATIC", L"Downloads",
            WS_CHILD | WS_VISIBLE | SS_CENTERIMAGE, 10, 10, 200, 30, hwnd, nullptr, GetModuleHandle(nullptr), nullptr);
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(wParam) == 1) {
            ShellExecuteW(nullptr, L"open", Browser::get().getAppDataPath().c_str(), nullptr, nullptr, SW_SHOW);
        }
        return 0;
    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wParam;
        SetBkColor(dc, RGB(40, 40, 40));
        SetTextColor(dc, RGB(220, 220, 220));
        return (LRESULT)CreateSolidBrush(RGB(40, 40, 40));
    }
    case WM_CLOSE:
        ShowWindow(hwnd, SW_HIDE);
        Browser::get().downloadsVisible = false;
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK Browser::MenuProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case 1: Browser::get().createTab(); break;
        case 2: /* new window */ break;
        case 3: Browser::get().showBookmarks(); break;
        case 4: Browser::get().showHistory(); break;
        case 5: Browser::get().showDownloads(); break;
        case 6: Browser::get().showSettings(); break;
        case 7: PostMessageW(Browser::get().getWindow(), WM_CLOSE, 0, 0); break;
        }
        ShowWindow(hwnd, SW_HIDE);
        return 0;
    case WM_LBUTTONDOWN:
    case WM_RBUTTONDOWN:
    case WM_MOUSEMOVE:
        if (msg != WM_MOUSEMOVE) ShowWindow(hwnd, SW_HIDE);
        return 0;
    case WM_MOUSELEAVE:
        ShowWindow(hwnd, SW_HIDE);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

std::wstring Browser::processAssistantMessage(const std::wstring& msg) {
    std::wstring lower = msg;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::towlower);

    if (lower.find(L"translate") != std::wstring::npos || lower.find(L"cevir") != std::wstring::npos)
        return L"I can help translate! Say: translate [text] to [language]";
    if (lower.find(L"hello") != std::wstring::npos || lower.find(L"merhaba") != std::wstring::npos || lower.find(L"hi") != std::wstring::npos)
        return L"Hello! I'm FewMB, your AI assistant. How can I help you today?";
    if (lower.find(L"help") != std::wstring::npos || lower.find(L"yardim") != std::wstring::npos)
        return L"I can help with: translations, code explanations, summaries, general questions, and more!";
    if (lower.find(L"weather") != std::wstring::npos || lower.find(L"hava") != std::wstring::npos)
        return L"I don't have access to weather data, but I can help you search for it!";
    if (isCode(msg))
        return L"I see code! I can help explain, debug, or suggest improvements. What would you like to know?";
    if (lower.find(L"who are you") != std::wstring::npos || lower.find(L"kimsin") != std::wstring::npos)
        return L"I'm FewMB, a lightweight browser with built-in AI assistant. I can help with translations, code, explanations, and general questions!";

    return L"I'm FewMB, your assistant! Ask me about: translations, code, explanations, or just chat with me!";
}

bool Browser::isCode(const std::wstring& text) {
    std::vector<std::wstring> kws = { L"function ", L"def ", L"class ", L"var ", L"const ", L"if ", L"for ",
        L"while ", L"return ", L"import ", L"public ", L"private ", L"void ", L"int ", L"string ", L"struct ", L"enum " };
    for (auto& kw : kws) {
        if (text.find(kw) != std::wstring::npos) return true;
    }
    return false;
}

void Browser::showContextMenu(int x, int y) {
    HMENU menu = CreatePopupMenu();
    AppendMenuW(menu, MF_STRING, 1001, L"Back\tAlt+Left");
    AppendMenuW(menu, MF_STRING, 1002, L"Forward\tAlt+Right");
    AppendMenuW(menu, MF_STRING, 1003, L"Refresh\tF5");
    AppendMenuW(menu, MF_SEPARATOR, 0, L"");
    AppendMenuW(menu, MF_STRING, 1004, L"Copy");
    AppendMenuW(menu, MF_STRING, 1005, L"Paste");
    AppendMenuW(menu, MF_STRING, 1006, L"Select All");
    AppendMenuW(menu, MF_SEPARATOR, 0, L"");
    AppendMenuW(menu, MF_STRING, 1007, L"Inspect Element\tCtrl+Shift+I");
    AppendMenuW(menu, MF_STRING, 1008, L"View Page Source\tCtrl+U");

    TrackPopupMenu(menu, TPM_RIGHTBUTTON | TPM_LEFTALIGN, x, y, 0, hwnd, nullptr);
    DestroyMenu(menu);
}

void Browser::hideContextMenu() {
    if (contextMenuWnd) {
        ShowWindow(contextMenuWnd, SW_HIDE);
    }
}

void Browser::run() {
    running = true;
    MSG msg;
    while (running && GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

void Browser::shutdown() {
    running = false;
    saveConfig();
    for (auto& t : tabs) {
        if (t->webView) t->webView->Close();
    }
    tabs.clear();
    log("FewMB shutdown");
}

std::wstring Browser::parseUrl(const std::wstring& input) { return input; }
std::wstring Browser::timestamp() {
    auto now = std::chrono::system_clock::now();
    auto t = std::chrono::system_clock::to_time_t(now);
    std::wstringstream ss;
    ss << std::put_time(std::localtime(&t), L"%H:%M:%S");
    return ss.str();
}

void Browser::log(const std::string& msg, int level) {
    std::wstring path = getAppDataPath() + L"\\fewmb.log";
    std::wofstream f(path, std::ios::app);
    if (f.is_open()) {
        f << timestamp() << L" [" << (level == 0 ? L"INFO" : level == 4 ? L"ERROR" : L"WARN") << L"] ";
        f << a2w(msg) << L"\n";
        f.close();
    }
}

std::string Browser::w2a(const std::wstring& w) {
    if (w.empty()) return "";
    int size = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr);
    std::string s(size, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], size, nullptr, nullptr);
    return s;
}

std::wstring Browser::a2w(const std::string& a) {
    if (a.empty()) return L"";
    int size = MultiByteToWideChar(CP_UTF8, 0, a.c_str(), -1, nullptr, 0);
    std::wstring s(size, 0);
    MultiByteToWideChar(CP_UTF8, 0, a.c_str(), -1, &s[0], size);
    return s;
}

}

using namespace FewMB;

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPWSTR cmd, int show) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    Browser::get().init();
    Browser::get().run();
    CoUninitialize();
    return 0;
}