#pragma once

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <shlobj.h>
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <atomic>
#include <mutex>
#include <algorithm>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <random>
#include <cctype>
#include <cstring>
#include <WebView2.h>
#include <Urlmon.h>
#include <winhttp.h>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "uuid.lib")

namespace FewMB {

constexpr wchar_t CLASS_NAME[] = L"FewMBrowser";
constexpr wchar_t TAB_CLASS[] = L"FewMTabBar";
constexpr wchar_t ASSISTANT_CLASS[] = L"FewMAssistant";
constexpr wchar_t SETTINGS_CLASS[] = L"FewMSettings";
constexpr wchar_t DOWNLOADS_CLASS[] = L"FewMDownloads";
constexpr wchar_t MENU_CLASS[] = L"FewMMenu";

constexpr int TOOLBAR_HEIGHT = 48;
constexpr int TAB_HEIGHT = 36;
constexpr int STATUS_HEIGHT = 24;
constexpr int PANEL_WIDTH = 350;

struct Color {
    uint8_t r, g, b, a;
    ColorId getId() const;
};

struct Tab {
    int id;
    std::wstring title;
    std::wstring url;
    bool isLoading;
    double progress;
    bool canGoBack;
    bool canGoForward;
    IWebView2WebView* webView;
    Tab(int i) : id(i), isLoading(false), progress(0), canGoBack(false), canGoForward(false), webView(nullptr) {}
};

class Browser {
public:
    static Browser& get();
    
    void init();
    void run();
    void shutdown();
    
    Tab* createTab(const std::wstring& url = L"");
    void closeTab(int id);
    Tab* getTab(int id);
    Tab* getActiveTab();
    void setActiveTab(int id);
    const std::vector<std::shared_ptr<Tab>>& getTabs() const { return tabs; }
    int getActiveTabId() const { return activeTabId; }
    
    void navigate(const std::wstring& url);
    void navigateBack();
    void navigateForward();
    void refresh();
    
    void showAssistant();
    void hideAssistant();
    bool isAssistantVisible() const { return assistantVisible; }
    
    void showSettings();
    void hideSettings();
    bool isSettingsVisible() const { return settingsVisible; }
    
    void showDownloads();
    void hideDownloads();
    bool isDownloadsVisible() const { return downloadsVisible; }
    
    void showBookmarks();
    void hideBookmarks();
    bool isBookmarksVisible() const { return bookmarksVisible; }
    
    void showHistory();
    void hideHistory();
    bool isHistoryVisible() const { return historyVisible; }
    
    void showContextMenu(int x, int y);
    void hideContextMenu();
    
    void setSplitMode(int mode);
    int getSplitMode() const { return splitMode; }
    
    void setTheme(int theme);
    int getTheme() const { return currentTheme; }
    bool isDarkMode() const;
    
    void showMenu();
    void hideMenu();
    
    HWND getWindow() const { return hwnd; }
    HWND getTabBar() const { return tabBarWnd; }
    
    void checkForUpdates();
    
    bool isUpdateAvailable() const { return updateAvailable; }
    std::wstring getLatestVersion() const { return latestVersion; }
    void downloadAndInstallUpdate();
    
    void executeJs(const std::wstring& script);
    
    std::wstring getAppDataPath();
    std::wstring getConfigPath();
    void saveConfig();
    void loadConfig();
    
    void addBookmark(const std::wstring& url, const std::wstring& title);
    void removeBookmark(int id);
    std::vector<Bookmark> getBookmarks();
    std::vector<Bookmark> searchBookmarks(const std::wstring& query);
    
    void addToHistory(const std::wstring& url, const std::wstring& title);
    std::vector<HistoryItem> getHistory(int limit = 100);
    std::vector<HistoryItem> searchHistory(const std::wstring& query);
    void clearHistory(int64_t before = 0);
    
    std::string startDownload(const std::wstring& url);
    void pauseDownload(const std::string& id);
    void resumeDownload(const std::string& id);
    void cancelDownload(const std::string& id);
    std::vector<DownloadItem> getDownloads();
    
    void setOnAssistantMessage(std::function<void(const std::wstring&)> cb) { onAssistantMsg = cb; }

    void showContextMenu(int x, int y);
    void hideContextMenu();
    std::wstring processAssistantMessage(const std::wstring& msg);
    bool isCode(const std::wstring& text);

private:
    Browser();
    ~Browser();
    
    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK TabBarProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK AssistantProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK SettingsProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK DownloadsProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK MenuProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
    
    void createWindow();
    void createControls();
    void createTabBar();
    void createAssistantWindow();
    void createSettingsWindow();
    void createDownloadsWindow();
    void createContextMenu();
    void createTrayIcon();
    
    void updateLayout();
    void updateTabBar();
    void updateAddressBar();
    void updateStatusBar();
    void updateTheme();
    
    void applyTheme(HWND hwnd);
    
    bool createWebViewForTab(Tab* tab, HWND parent, const std::wstring& url);
    void destroyWebView(Tab* tab);
    
    std::wstring parseUrl(const std::wstring& input);
    void log(const std::string& msg, int level = 0);
    std::wstring timestamp();
    std::string w2a(const std::wstring& w);
    std::wstring a2w(const std::string& a);
    
    HWND hwnd = nullptr;
    HWND tabBarWnd = nullptr;
    HWND addressBar = nullptr;
    HWND backBtn = nullptr, *forwardBtn = nullptr, *refreshBtn = nullptr;
    HWND homeBtn = nullptr, *menuBtn = nullptr;
    HWND assistantBtn = nullptr, *bookmarksBtn = nullptr;
    HWND downloadsBtn = nullptr, *settingsBtn = nullptr;
    HWND contentWnd = nullptr, *statusWnd = nullptr;
    HWND splitWnd = nullptr;
    
    HWND assistantWnd = nullptr;
    HWND settingsWnd = nullptr;
    HWND downloadsWnd = nullptr;
    HWND contextMenuWnd = nullptr;
    HWND trayIcon = nullptr;
    
    std::vector<std::shared_ptr<Tab>> tabs;
    std::atomic<int> nextTabId;
    std::atomic<int> activeTabId;
    std::atomic<bool> running;
    
    std::atomic<bool> assistantVisible;
    std::atomic<bool> settingsVisible;
    std::atomic<bool> downloadsVisible;
    std::atomic<bool> bookmarksVisible;
    std::atomic<bool> historyVisible;
    
    int currentTheme = 2;
    int splitMode = 0;
    
    bool updateAvailable = false;
    std::wstring latestVersion;
    std::wstring downloadUrl;
    
    std::vector<Bookmark> bookmarks;
    std::vector<HistoryItem> history;
    std::vector<DownloadItem> downloads;
    
    HFONT titleFont, uiFont, monoFont;
    HBRUSH bgBrush, fgBrush, borderBrush;
    HPEN borderPen;
    
    std::mutex tabsMutex;
    std::function<void(const std::wstring&)> onAssistantMsg;
    
    bool assistantInitialized = false;
    std::wstring assistantHistory;
};

}

using namespace FewMB;